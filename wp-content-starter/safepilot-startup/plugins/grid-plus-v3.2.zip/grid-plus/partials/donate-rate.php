<?php
/**
 * Created by PhpStorm.
 * User: MyPC
 * Date: 05/06/2018
 * Time: 11:18 SA
 */
?>
<div style="margin-top: 30px; padding: 5px 30px; text-align: center; border: solid 3px #cccccc;">
		<p><?php esc_html_e('Need more information?', 'grid-plus') ?>
		<br>
<a href="http://plugins.g5plus.net/documents/grid-plus/"><?php esc_html_e('Documentation', 'grid-plus') ?></a>
- <a href="http://support.g5plus.net/forums/forum/plugins/grid-plus/"><?php esc_html_e('Support Forum', 'grid-plus') ?></a>
            - <a href="https://codecanyon.net/item/grid-plus-unlimited-grid-layout/reviews/19444153"><?php esc_html_e('Rate Us', 'grid-plus') ?></a>
		</p>
        <p><?php esc_html_e('Thank you very much!', 'grid-plus') ?></p>
	</div>